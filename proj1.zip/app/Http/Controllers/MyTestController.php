<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MyTestController extends Controller
{
    public function mystore(Request $request)
    {
        //
        dd($request->i1);
    }
}

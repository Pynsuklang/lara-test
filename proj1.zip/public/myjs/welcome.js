$(document).ready(function () {
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    });

            $('input[name="daterange"]').daterangepicker({
                multidate: true,
                format: 'dd-mm-yyyy'
            });

    $("#myform").on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: "test-sub",
            dataType: "JSON",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(response) {
                alert("Data updated successfully");
                location.reload();
            },
            error: function(response) {
                alert("ERROR");
            }
        });
    });    
});